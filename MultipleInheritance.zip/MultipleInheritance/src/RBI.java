public interface RBI {
    int rateOfInterest();
}
