public class BOI implements RBI,BankPolicy {

    public void bankName(){
        System.out.println("we are BOI , happy to serve our customers");
    }
    @Override
    public int rateOfInterest() {
        return 6;
    }

    @Override
    public void typeOfPolicy() {
        System.out.println("special offer to students and elderly citizens");
    }

    public int getrateOfInterest(int b){
        b = b*rateOfInterest();
        return b;

    }
}
