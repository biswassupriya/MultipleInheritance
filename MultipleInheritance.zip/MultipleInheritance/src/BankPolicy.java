public interface BankPolicy {
    void typeOfPolicy();
}
