
public class SBI implements RBI,BankPolicy{
   int amount = 500;
    @Override
    public int rateOfInterest() {
        return 2;
    }

    @Override
    public void typeOfPolicy() {
        System.out.println("must have 500 rupees in the savings account else the account will be blocked ");
    }

    public int getrateOfInterest(int a){
        amount = amount*rateOfInterest();
        return amount;

    }

    public int gettotalrateOfInterest(int a){
        a = a*rateOfInterest();
        return a;

    }

    public void bankName(){
        System.out.println("Welcome to SBI Bank");
    }
}
