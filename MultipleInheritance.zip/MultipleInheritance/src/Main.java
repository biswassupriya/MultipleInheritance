
public class Main {
    public static void main(String[] args) {
        SBI s = new SBI();
        //s.rateOfInterest();
        s.bankName();
        System.out.println(s.rateOfInterest());
        s.typeOfPolicy();
        System.out.println("£"+s.amount);
        System.out.println("amount after 2% interest is "+ " " +"£" + s.getrateOfInterest(2));
        System.out.println("with 2% interest the amount you receive is "+ " "+"£"+s.gettotalrateOfInterest(3000));


        PNB p = new PNB();
        p.bankName();
        p.typeOfPolicy();
        System.out.println("interest is " + " "+p.rateOfInterest()+"% interest");
        System.out.println("£"+p.getrateOfInterest(200));

        BOI b = new BOI();
        b.bankName();
        b.typeOfPolicy();
        System.out.println(p.rateOfInterest()+"%");
        System.out.println("£"+s.getrateOfInterest(4000));

    }
}
