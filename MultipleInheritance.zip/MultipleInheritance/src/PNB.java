public class PNB implements RBI,BankPolicy {
    @Override
    public int rateOfInterest() {
        return 3;
    }

    @Override
    public void typeOfPolicy() {
        System.out.println(" Okay to have zero balance in the savings account ");
    }

    public int getrateOfInterest(int a){
        a= a*rateOfInterest();
        return a;

    }

    public void bankName(){
        System.out.println("WE ARE PNB HOW CAN WE SERVE YOU");
    }
}
